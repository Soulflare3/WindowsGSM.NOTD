# WindowsGSM.NOTD
🧩 WindowsGSM plugin that provides Night of the Dead Dedicated server support!

## IMPORTANT
*Change in ServerSettings.ini Servername,Adminpassword,Serverpassword*

## Requirements
[WindowsGSM](https://github.com/WindowsGSM/WindowsGSM) >= 1.21.0

## Installation
1. Download the latest release
1. Move **NOTD.cs** folder to **plugins** folder or import the zip from the plugins tab
1. Click the **[RELOAD PLUGINS]** button or restart WindowsGSM
